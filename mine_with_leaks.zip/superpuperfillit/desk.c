/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   desk.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbeqqo <gbeqqo@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/04/23 15:50:52 by gbeqqo            #+#    #+#             */
/*   Updated: 2019/04/25 16:03:23 by bellyn-t         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/fill.h"
#include "libft/libft.h"

char		**draw_desk(int size)
{
	char	**desk;
	int		i;

	i = 0;
	if (!(desk = (char**)malloc(sizeof(char *) * size)))
		stop();
	while (i < size)
	{
		if (!(desk[i] = ft_strnew((size_t)size)))
		{
            while (--i)
                ft_strdel(&desk[i]);
            free(desk);
            stop();
        }
		ft_memset(desk[i], '.', (size_t)size);
		i++;
	}
	return (desk);
}

void		print_desk(t_desk *wow_desk)
{
	int i;
    int desk_size;
    char **desk_shape;

    desk_shape = wow_desk->desk_shape;
    desk_size = wow_desk->desk_size;
    i = 0;
	while (i < desk_size)
	{
		ft_putstr(desk_shape[i]);
		ft_putchar('\n');
		i++;
	}
}

void		add_pos(t_tetr *tetr, t_mark *start)
{
	tetr->position->row = start->row;
	tetr->position->col = start->col - br_mv(tetr);
}

char		**insert_to_desk(char **desk, int desk_size,\
t_mark *start, t_tetr *tetr)
{
	int		row;
	int		col;
	char	**tetr_shape;

	row = 0;
	tetr_shape = tetr->shape;
	while (row + start->row < desk_size && row < tetr->height)
	{
		col = 0;
		if ((start->col + tetr->width - br_mv(tetr)) <= desk_size)
		{
			while (tetr_shape[row][col] != '\0' && col < desk_size)
			{
				if (tetr_shape[row][col] != '.')
					desk[row + start->row][col + start->col - br_mv(tetr)] =\
					tetr_shape[row][col];
				col++;
			}
		}
		else
			return (NULL);
		row++;
	}
	add_pos(tetr, start);
	return (desk);
}

int			sizeof_desk(int fig_count, t_list *tetr_lst)
{
	int			i;
	t_tetr		*tetr;

	i = 2;
	tetr = (t_tetr *)(tetr_lst)->content;
	if (fig_count == 1)
	{
		if (tetr->width == 4 || tetr->height == 4)
			return (4);
		if (tetr->width == 3 || tetr->height == 3)
			return (3);
		if (tetr->width == 2 || tetr->height == 2)
			return (2);
	}
	while (i * i < fig_count * 4)
		i++;
	return (i);
}
